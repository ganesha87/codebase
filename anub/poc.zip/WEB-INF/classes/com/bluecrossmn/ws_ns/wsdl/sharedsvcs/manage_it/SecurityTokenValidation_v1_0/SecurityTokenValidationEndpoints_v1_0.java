/**
 * SecurityTokenValidationEndpoints_v1_0.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bluecrossmn.ws_ns.wsdl.sharedsvcs.manage_it.SecurityTokenValidation_v1_0;

public interface SecurityTokenValidationEndpoints_v1_0 extends javax.xml.rpc.Service {
    public java.lang.String getSecurityTokenValidationEndpoint_v1_0Address();

    public com.bluecrossmn.ws_ns.wsdl.sharedsvcs.manage_it.SecurityTokenValidation_v1_0.SecurityTokenValidationInterface_v1_0 getSecurityTokenValidationEndpoint_v1_0() throws javax.xml.rpc.ServiceException;

    public com.bluecrossmn.ws_ns.wsdl.sharedsvcs.manage_it.SecurityTokenValidation_v1_0.SecurityTokenValidationInterface_v1_0 getSecurityTokenValidationEndpoint_v1_0(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
