/**
 * SecurityTokenValidationInterface_v1_0.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.bluecrossmn.ws_ns.wsdl.sharedsvcs.manage_it.SecurityTokenValidation_v1_0;

public interface SecurityTokenValidationInterface_v1_0 extends java.rmi.Remote {
    public com.bluecrossmn.ws_ns.wsdl.sharedsvcs.manage_it.SecurityTokenValidation_v1_0.SendTokenResponse sendToken(com.bluecrossmn.ws_ns.wsdl.sharedsvcs.manage_it.SecurityTokenValidation_v1_0.SendTokenRequest sendTokenRequestValue) throws java.rmi.RemoteException;
    public com.bluecrossmn.ws_ns.wsdl.sharedsvcs.manage_it.SecurityTokenValidation_v1_0.ValidateTokenResponse validateToken(com.bluecrossmn.ws_ns.wsdl.sharedsvcs.manage_it.SecurityTokenValidation_v1_0.ValidateTokenRequest validateTokenRequestValue) throws java.rmi.RemoteException;
}
